################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc
import xbmcgui

import os

from resources.libs.common.config import CONFIG
from resources.libs.common import directory
from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.gui import window


def view_current():
    window.show_text_box(CONFIG.ADDONTITLE, tools.read_from_file(CONFIG.ADVANCED).replace('\t', '    '))


def remove_current():
    dialog = xbmcgui.Dialog()
    ok = dialog.yesno(CONFIG.ADDONTITLE, "[COLOR {0}]Bạn có đồng ý xóa file Advancedsettings.xml?[/COLOR]".format(CONFIG.COLOR2),
                                           yeslabel="[B][COLOR springgreen]Có[/COLOR][/B]",
                                           nolabel="[B][COLOR red]Không[/COLOR][/B]")

    if ok:
        if os.path.exists(CONFIG.ADVANCED):
            tools.remove_file(CONFIG.ADVANCED)
            logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, CONFIG.ADDONTITLE),
                               "[COLOR {0}]advancedsettings.xml xóa[/COLOR]".format(CONFIG.COLOR2))
            xbmc.executebuiltin('Container.Refresh()')
        else:
            logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, CONFIG.ADDONTITLE),
                               "[COLOR {0}]advancedsettings.xml không tìm thấy[/COLOR]".format(CONFIG.COLOR2))
    else:
        logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, CONFIG.ADDONTITLE),
                               "[COLOR {0}]advancedsettings.xml không xóa[/COLOR]".format(CONFIG.COLOR2))


def _write_setting(category, tag, value):
    from xml.etree import ElementTree

    exists = os.path.exists(CONFIG.ADVANCED)

    if exists:
        root = ElementTree.parse(CONFIG.ADVANCED).getroot()
    else:
        root = ElementTree.Element('advancedsettings')

    tree_category = root.find('./{0}'.format(category))
    if tree_category is None:
        tree_category = ElementTree.SubElement(root, category)

    category_tag = tree_category.find(tag)
    if category_tag is None:
        category_tag = ElementTree.SubElement(tree_category, tag)

    category_tag.text = '{0}'.format(value)

    tree = ElementTree.ElementTree(root)

    logging.log('Writing {0} - {1}: {2} to advancedsettings.xml'.format(category, tag, value), level=xbmc.LOGDEBUG)
    tree.write(CONFIG.ADVANCED)

    xbmc.executebuiltin('Container.Refresh()')


class AdvancedMenu:
    def __init__(self):
        self.dialog = xbmcgui.Dialog()

        self.tags = {}

    def show_menu(self, url=None):
        infoLabel = ['System.Memory(free)', 'System.Memory(used)', 'System.Memory(total)']
        data = []
        x = 0
        for info in infoLabel:
            temp = tools.get_info_label(info)
            y = 0
            while temp == "Busy" and y < 10:
                temp = tools.get_info_label(info)
                y += 1
                logging.log("{0} sleep {1}".format(info, str(y)))
                xbmc.sleep(200)
            data.append(temp)
            x += 1
        # ram_used = tools.convert_size(int(float(data[1][:-2])) * 1024 * 1024)
        ram_free = tools.convert_size(int(float(data[0][:-2])) * 1024 * 1024)
        # ram_total = tools.convert_size(int(float(data[2][:-2])) * 1024 * 1024)
        directory.add_file('[COLOR yellow][B]Tự Động Thiết lập bộ nhớ đệm theo dung lượng Ram[/B]',
                               {'mode': 'advanced_settings', 'action': 'auto_memcache'},description='Thiết lập thông số bộ nhớ đệm dựa vào dung lượng Ram trống trên thiết bị.', icon=CONFIG.ICONMAINT,
                               themeit=CONFIG.THEME3)
        directory.add_file('[COLOR {0}]Ram Còn Trống:[/COLOR] [COLOR {1}]{2}[/COLOR]'.format(CONFIG.COLOR1, CONFIG.COLOR2, ram_free), icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME2)
        directory.add_dir('Thay đổi thông số file Advancedsettings.xml',
                               {'mode': 'advanced_settings', 'action': 'show_section', 'tags': 'cache|network'}, icon=CONFIG.ICONMAINT,
                               themeit=CONFIG.THEME3)

        if os.path.exists(CONFIG.ADVANCED):
            directory.add_file('Xem file Advancedsettings.xml',
                               {'mode': 'advanced_settings', 'action': 'view_current'}, icon=CONFIG.ICONMAINT,
                               themeit=CONFIG.THEME3)
            directory.add_file('Xóa file Advancedsettings.xml',
                               {'mode': 'advanced_settings', 'action': 'remove_current'}, icon=CONFIG.ICONMAINT,
                               themeit=CONFIG.THEME3)
        #directory.add_separator(icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)
        
        # response = tools.open_url(CONFIG.ADVANCEDFILE)
        # url_response = tools.open_url(url)
        # local_file = os.path.join(CONFIG.ADDON_PATH, 'resources', 'text', 'advanced.json')

        # if url_response:
            # TEMPADVANCEDFILE = url_response.text
        # elif response:
            # TEMPADVANCEDFILE = response.text
        # elif os.path.exists(local_file):
            # TEMPADVANCEDFILE = tools.read_from_file(local_file)
        # else:
            # TEMPADVANCEDFILE = None
            # logging.log("[Advanced Settings] No Presets Available")
        
        # if TEMPADVANCEDFILE:
            # import json

            # directory.add_separator(icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)
            # try:
                # advanced_json = json.loads(TEMPADVANCEDFILE)
            # except:
                # advanced_json = None
                # logging.log("[Advanced Settings] ERROR: Invalid Format for {0}.".format(TEMPADVANCEDFILE))
                
            # if advanced_json:
                # presets = advanced_json['presets']
                # if presets and len(presets) > 0:
                    # for preset in presets:
                        # name = preset.get('name', '')
                        # section = preset.get('section', False)
                        # preseturl = preset.get('url', '')
                        # icon = preset.get('icon', CONFIG.ADDON_ICON)
                        # fanart = preset.get('fanart', CONFIG.ADDON_FANART)
                        # description = preset.get('description', '')

                        # if not name:
                            # logging.log('[Advanced Settings] Missing tag \'name\'', level=xbmc.LOGDEBUG)
                            # continue
                        # if not preseturl:
                            # logging.log('[Advanced Settings] Missing tag \'url\'', level=xbmc.LOGDEBUG)
                            # continue
                        
                        # if section:
                            # directory.add_dir(name, {'mode': 'advanced_settings', 'url': preseturl},
                                              # description=description, icon=icon, fanart=fanart, themeit=CONFIG.THEME3)

                        # else:
                            # directory.add_file(name,
                                               # {'mode': 'advanced_settings', 'action': 'write_advanced', 'name': name,
                                                # 'url': preseturl},
                                               # description=description, icon=icon, fanart=fanart, themeit=CONFIG.THEME2)
        # else:
            # logging.log("[Advanced Settings] URL not working: {0}".format(CONFIG.ADVANCEDFILE))
        
    def auto_memcache(self):            
        dialog = xbmcgui.Dialog()
        choice = self.dialog.yesno(CONFIG.ADDONTITLE,
                                           "[COLOR {0}]Bạn có muốn thiết lập file [COLOR {1}]AdvancedSetting.xml[/COLOR] ngay không?[/COLOR]".format(
                                               CONFIG.COLOR2, CONFIG.COLOR1),
                                           yeslabel="[B][COLOR springgreen]OK Thiết Lập![/COLOR][/B]",
                                           nolabel="[B][COLOR red]Hủy[/COLOR][/B]")       
        if choice == 1:                                        
            name = 'Tự động cài đặt bộ nhớ cache'
            self.write_advanced(name, CONFIG.ADVANCEDFILE)
        else: return
        
    def quick_configure(self):
        directory.add_file('Các thay đổi sẽ không được phản ánh cho đến khi Kodi được khởi động lại.', icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)
        directory.add_file('Nhấp vào đây để khởi động lại Kodi.', {'mode': 'forceclose'}, icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)
        directory.add_file('Các danh mục khác sắp ra mắt :)', icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)
        directory.add_separator(middle='THỂ LOẠI')
        directory.add_dir('Mạng và bộ nhớ đệm', {'mode': 'advanced_settings', 'action': 'show_section', 'tags': 'cache|network'}, icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)

    def show_section(self, tags):
        from xml.etree import ElementTree

        split_tags = tags.split('|')
        logging.log(split_tags)

        exists = os.path.exists(CONFIG.ADVANCED)

        if exists:
            root = ElementTree.parse(CONFIG.ADVANCED).getroot()

            for category in root.findall('*'):
                name = category.tag
                if name not in split_tags:
                    continue

                values = {}

                for element in category.findall('*'):
                    values[element.tag] = element.text

                self.tags[name] = values

        if len(self.tags) == 0:
            directory.add_file('Không có cài đặt nào cho danh mục này tồn tại trong hiện tại của bạn advancedsettings.xml file.', icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)
            directory.add_separator()
            
        for category in self.tags:
            directory.add_separator(category.upper())

            for tag in self.tags[category]:
                value = self.tags[category][tag]

                if value is None:
                    value = ''

                directory.add_file('{0}: {1}'.format(tag, value), {'mode': 'advanced_settings', 'action': 'set_setting',
                                                                   'category': category, 'tag': tag, 'value': value},
                                   icon=CONFIG.ICONMAINT, themeit=CONFIG.THEME3)

    def set_setting(self, category, tag, current):
        value = None
        
        if category == 'Bộ nhớ đệm':
            value = self._cache(tag, current)
        elif category == 'Mạng':
            value = self._network(tag, current)
            
        if value:
            _write_setting(category, tag, value)
            
    def _cache(self, tag, current):
        value = None
        
        if tag == 'chế độ đệm':
            values = ['Bộ đệm tất cả các hệ thống tệp internet',
                      'Bộ đệm tất cả các hệ thống tệp',
                      'Chỉ đệm các hệ thống tệp internet thực sự',
                      'Không có bộ đệm',
                      'Tất cả các hệ thống tệp mạng']
                      
            items = []
            for i in range(len(values)):
                items.append(xbmcgui.ListItem(label=str(i), label2=values[i]))
                      
            value = self.dialog.select('Chọn một giá trị', items, preselect=int(current), useDetails=True)
        elif tag == 'kích thước bộ nhớ':
            free_memory = tools.get_info_label('System.Memory(free)')
            free_converted = tools.convert_size(int(float(free_memory[:-2])) * 1024 * 1024)
            
            recommended = int(float(free_memory[:-2]) / 3) * 1024 * 1024
            recommended_converted = tools.convert_size(int(float(free_memory[:-2]) / 3) * 1024 * 1024)
        
            value = tools.get_keyboard(default='{0}'.format(recommended), heading='Dung lượng Memcache tính theo Bytes\n(Đề xuất: {0} = {1})'.format(recommended_converted, recommended))
        elif tag == 'Người đọc':
            value = tools.get_keyboard(default='{0}'.format(current), heading='Tỷ lệ lấp đầy bộ nhớ đệm\n(Số lượng cao sẽ gây ra việc sử dụng nhiều băng thông!)')
            
        return value
            
    def _network(self, tag, current):
        msgs = {'curlclienttimeout': 'Hết thời gian chờ tính bằng giây cho các kết nối libcurl (http / ftp)',
                'curllowspeedtime': 'Thời gian tính bằng giây để libcurl xem xét tốc độ kết nối thấp',
                'curlretries': 'Số lần thử lại cho một số hoạt động libcurl không thành công (e.g. timeout)',
                'httpproxyusername': 'Tên người dùng để xác thực proxy cơ bản',
                'httpproxypassword': 'Mật khẩu để xác thực proxy cơ bản'}
        
        value = tools.get_keyboard(default='{0}'.format(current), heading=msgs[tag])
            
        return value
                
    def write_advanced(self, name, url):
        response = tools.open_url(url)

        if response:
            if os.path.exists(CONFIG.ADVANCED):
                choice = self.dialog.yesno(CONFIG.ADDONTITLE,
                                           "[COLOR {0}]Bạn có muốn ghi đè file [COLOR {1}]AdvancedSettings.xml[/COLOR] hiện có?[/COLOR]".format(
                                               CONFIG.COLOR2, CONFIG.COLOR1),
                                           yeslabel="[B][COLOR springgreen]Ghi đè[/COLOR][/B]",
                                           nolabel="[B][COLOR red]Hủy [/COLOR][/B]")
            else:
                choice = self.dialog.yesno(CONFIG.ADDONTITLE,
                                           "[COLOR {0}]Bạn đã đồng ý ghi đè file [COLOR {1}]AdvancedSettings.xml[/COLOR] \nNhấn [COLOR springgreen]Cài Đặt[/COLOR] để xác nhận." .format(
                                               CONFIG.COLOR2, CONFIG.COLOR1),
                                           yeslabel="[B][COLOR springgreen]Cài Đặt[/COLOR][/B]",
                                           nolabel="[B][COLOR red]Hủy[/COLOR][/B]")

            if choice == 1:
                tools.write_to_file(CONFIG.ADVANCED, response.text)
                self.dialog.ok(CONFIG.ADDONTITLE, 'Bộ nhớ đệm sẽ được lấy tự động dựa vào dung lượng ram trống hiện có.')
                category = 'cache'
                tag = 'memorysize'
                value = None
                self.set_setting(category, tag, value) 
                tools.kill_kodi(msg='[COLOR {0}]File AdvancedSettings.xml đã được thiết lập, bạn cần khởi động lại Kodi để có hiệu lực.[/COLOR]'.format(
                                   CONFIG.COLOR2))
            else:
                logging.log("[Advanced Settings] Cài đặt bị hủy")
                logging.log_notify('[COLOR {0}]{1}[/COLOR]'.format(CONFIG.COLOR1, CONFIG.ADDONTITLE),
                                   "[COLOR {0}]Viết bị hủy![/COLOR]".format(CONFIG.COLOR2))
                return
        else:
            logging.log("[Advanced Settings] URL không hoạt động: {0}".format(url))
            logging.log_notify('[COLOR {0}]{1}[/COLOR]'.format(CONFIG.COLOR1, CONFIG.ADDONTITLE),
                               "[COLOR {0}]URL không hoạt động[/COLOR]".format(CONFIG.COLOR2))

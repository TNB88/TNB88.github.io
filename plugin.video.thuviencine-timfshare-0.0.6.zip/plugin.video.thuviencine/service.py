# -*- coding: utf-8 -*-
# TimFshare build: no background service needed.
import xbmc
xbmc.log('[TimFshare] service loaded', xbmc.LOGINFO)

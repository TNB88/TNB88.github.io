from urllib.parse import urlencode, parse_qsl, quote_plus, urljoin, urlparse, parse_qs
from urllib.request import Request, urlopen
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from collections import OrderedDict
from html import unescape as html_unescape
import re
import sys
import xbmc
import xbmcgui

try:
    from bs4 import BeautifulSoup
except:
    BeautifulSoup = None

addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon = Addon()
addon_name = addon.getAddonInfo('name')
addon_icon = addon.getAddonInfo('icon')

CINEHAY_BASE = 'https://cinehay.net/'
CINEHAY_INDEX = urljoin(CINEHAY_BASE, 'index.php')
CINEHAY_ICON = urljoin(CINEHAY_BASE, 'favicon-192x192.png')
REQUEST_TIMEOUT = 12
CACHE_SECONDS = 300
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Referer': CINEHAY_BASE
}

LISTINGS = OrderedDict((
    ('Trang chủ / Phim hot', 'index.php'),
    ('Phim lẻ', 'danh-sach/phim-le'),
    ('Phim bộ', 'danh-sach/phim-bo'),
    ('Đang chiếu', 'danh-sach/phim-dang-chieu'),
    ('Sắp chiếu', 'danh-sach/phim-sap-chieu')
))

GENRES = OrderedDict((
    ('Hành động', 'the-loai/hanh-dong'),
    ('Tình cảm', 'the-loai/tinh-cam'),
    ('Hài hước', 'the-loai/hai-huoc'),
    ('Cổ trang', 'the-loai/co-trang'),
    ('Tâm lý', 'the-loai/tam-ly'),
    ('Hình sự', 'the-loai/hinh-su'),
    ('Chiến tranh', 'the-loai/chien-tranh'),
    ('Thể thao', 'the-loai/the-thao'),
    ('Võ thuật', 'the-loai/vo-thuat'),
    ('Viễn tưởng', 'the-loai/vien-tuong'),
    ('Phiêu lưu', 'the-loai/phieu-luu'),
    ('Khoa học', 'the-loai/khoa-hoc'),
    ('Kinh dị', 'the-loai/kinh-di'),
    ('Âm nhạc', 'the-loai/am-nhac'),
    ('Thần thoại', 'the-loai/than-thoai'),
    ('Tài liệu', 'the-loai/tai-lieu'),
    ('Gia đình', 'the-loai/gia-dinh'),
    ('Chính kịch', 'the-loai/chinh-kich'),
    ('Bí ẩn', 'the-loai/bi-an'),
    ('Học đường', 'the-loai/hoc-duong'),
    ('Kinh điển', 'the-loai/kinh-dien'),
    ('18+', 'the-loai/phim-18')
))

COUNTRIES = OrderedDict((
    ('Âu Mỹ', 'quoc-gia/au-my'),
    ('Hàn Quốc', 'quoc-gia/han-quoc'),
    ('Trung Quốc', 'quoc-gia/trung-quoc'),
    ('Nhật Bản', 'quoc-gia/nhat-ban'),
    ('Thái Lan', 'quoc-gia/thai-lan'),
    ('Hồng Kông', 'quoc-gia/hong-kong'),
    ('Đài Loan', 'quoc-gia/dai-loan'),
    ('Ấn Độ', 'quoc-gia/an-do'),
    ('Việt Nam', 'quoc-gia/viet-nam'),
    ('Anh', 'quoc-gia/anh'),
    ('Philippines', 'quoc-gia/philippines'),
    ('Quốc gia khác', 'quoc-gia/quoc-gia-khac')
))

YEARS = OrderedDict((str(year), f'nam-phat-hanh/{year}') for year in range(2026, 2015, -1))


def get_url(**kwargs):
    return f'{addon_url}?{urlencode(kwargs)}'


def get_int(value, default=1):
    try:
        return int(value)
    except:
        return default


def clean_text(value):
    return str(value or '').strip()


def log_error(message):
    try:
        xbmc.log(f'{addon_name}: {message}', xbmc.LOGERROR)
    except:
        pass


def notify(message, duration=2500):
    try:
        xbmc.executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, message, duration, addon_icon))
    except:
        pass


def html_text(value):
    value = clean_text(value)
    if not value:
        return ''
    value = re.sub(r'(?is)<(script|style).*?</\1>', ' ', value)
    value = re.sub(r'(?s)<[^>]+>', ' ', value)
    return re.sub(r'\s+', ' ', html_unescape(value)).strip()


def html_attr(value, name):
    match = re.search(r'\b%s\s*=\s*([\'"])(.*?)\1' % re.escape(name), clean_text(value), re.I | re.S)
    return html_unescape(match.group(2)).strip() if match else ''


def soup_text(element):
    if not element:
        return ''
    try:
        return html_text(element.get_text(' ', strip=True))
    except:
        return html_text(element)


def soup_attr(element, name):
    try:
        return html_unescape(clean_text(element.get(name)))
    except:
        return ''


def cinehay_url(value):
    value = html_unescape(clean_text(value))
    if not value:
        return CINEHAY_INDEX
    return urljoin(CINEHAY_BASE, value)


def page_url(path, page=1):
    url = cinehay_url(path or 'index.php')
    page = get_int(page, 1)
    if page > 1 and not re.search(r'([?&])page=', url):
        url = f'{url}{"&" if "?" in url else "?"}page={page}'
    return url


def get_text(url, referer=''):
    try:
        headers = dict(HEADERS)
        if referer:
            headers['Referer'] = referer
        request = Request(cinehay_url(url), headers=headers)
        response = urlopen(request, timeout=REQUEST_TIMEOUT)
        return response.read().decode('utf-8-sig', 'replace')
    except Exception as error:
        log_error(f'Không tải được trang: {url} - {error}')
        return ''


def first_regex(text, pattern, default=''):
    match = re.search(pattern, text or '', re.I | re.S)
    return html_unescape(match.group(1)).strip() if match else default


def style_background_url(value):
    return first_regex(value, r'background-image\s*:\s*url\((?:[\'"])?([^\'")]+)')


def meta_content(html, key, attr='property'):
    pattern = r'<meta[^>]+%s=["\']%s["\'][^>]+content=["\']([^"\']*)' % (re.escape(attr), re.escape(key))
    value = first_regex(html, pattern)
    if value:
        return value
    pattern = r'<meta[^>]+content=["\']([^"\']*)["\'][^>]+%s=["\']%s["\']' % (re.escape(attr), re.escape(key))
    return first_regex(html, pattern)


def year_from_text(text):
    match = re.search(r'\b(19|20)\d{2}\b', clean_text(text))
    return get_int(match.group(0), 0) if match else 0


def movie_key(url):
    return clean_text(url).lower().split('#', 1)[0]


def movie_label(item):
    title = clean_text(item.get('title')) or 'CineHay'
    extras = []
    if item.get('quality'):
        extras.append(f'[COLOR lightgreen]{item.get("quality")}[/COLOR]')
    if item.get('episode'):
        extras.append(f'[COLOR deepskyblue]{item.get("episode")}[/COLOR]')
    if item.get('year'):
        extras.append(f'[COLOR gray]{item.get("year")}[/COLOR]')
    return f'{title} {" ".join(extras)}'.strip()


def plot_text(item):
    meta = []
    for key in ('original', 'quality', 'episode', 'status', 'duration', 'year', 'genre', 'country', 'director', 'cast'):
        value = clean_text(item.get(key))
        if value and value not in meta:
            meta.append(value)
    plot = clean_text(item.get('plot'))
    return '\n'.join(part for part in (' | '.join(meta), plot) if part)


def set_video_info(list_item, item, media_type='movie'):
    title = clean_text(item.get('title'))
    plot = plot_text(item)
    try:
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(plot)
        info_tag.setMediaType(media_type)
        year = get_int(item.get('year'), 0)
        if year:
            info_tag.setYear(year)
        genres = [part.strip() for part in clean_text(item.get('genre')).split(',') if part.strip()]
        if genres:
            info_tag.setGenres(genres)
        original = clean_text(item.get('original'))
        if original:
            info_tag.setOriginalTitle(original)
    except:
        try:
            info = {'title': title, 'plot': plot}
            if item.get('year'):
                info['year'] = item.get('year')
            if item.get('genre'):
                info['genre'] = item.get('genre')
            list_item.setInfo('video', info)
        except:
            pass


def add_item(item, url, is_folder=True, label=None, media_type='movie'):
    poster = clean_text(item.get('poster')) or CINEHAY_ICON
    fanart = clean_text(item.get('fanart')) or poster
    list_item = xbmcgui.ListItem(label=label or movie_label(item))
    list_item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart})
    set_video_info(list_item, item, media_type)
    list_item.setProperty('IsPlayable', 'false' if is_folder else 'true')
    addDirectoryItem(HANDLE, url, list_item, is_folder)


def add_nav(title, target_url, detail='', image=None):
    item = {'title': title, 'poster': image or CINEHAY_ICON, 'fanart': image or CINEHAY_ICON, 'plot': detail}
    add_item(item, target_url, True, title, 'video')


def parse_card(card):
    if BeautifulSoup and hasattr(card, 'select_one'):
        href = cinehay_url(soup_attr(card, 'href'))
        poster = cinehay_url(soup_attr(card.select_one('img'), 'src'))
        title = soup_attr(card, 'title') or soup_text(card.select_one('.movie-card-title'))
        original = soup_text(card.select_one('.movie-card-sub'))
        quality = soup_text(card.select_one('.badge.quality'))
        episode = soup_text(card.select_one('.badge.episode'))
        year = year_from_text(soup_text(card.select_one('.card-year')))
        return {
            'url': href,
            'title': title,
            'original': original,
            'poster': poster,
            'fanart': poster,
            'quality': quality,
            'episode': episode,
            'year': year,
            'plot': original
        }
    attrs, body = card
    poster = first_regex(body, r'<img[^>]+src=["\']([^"\']+)')
    badges = [html_text(value) for value in re.findall(r'<span[^>]+class=["\'][^"\']*badge[^"\']*["\'][^>]*>(.*?)</span>', body, re.I | re.S)]
    return {
        'url': cinehay_url(html_attr(attrs, 'href')),
        'title': html_attr(attrs, 'title') or html_text(first_regex(body, r'<h3[^>]+class=["\'][^"\']*movie-card-title[^"\']*["\'][^>]*>(.*?)</h3>')),
        'original': html_text(first_regex(body, r'<p[^>]+class=["\'][^"\']*movie-card-sub[^"\']*["\'][^>]*>(.*?)</p>')),
        'poster': cinehay_url(poster) if poster else CINEHAY_ICON,
        'fanart': cinehay_url(poster) if poster else CINEHAY_ICON,
        'quality': badges[0] if badges else '',
        'episode': badges[1] if len(badges) > 1 else '',
        'year': year_from_text(first_regex(body, r'<span[^>]+class=["\'][^"\']*card-year[^"\']*["\'][^>]*>(.*?)</span>'))
    }


def parse_hero(html):
    movies = []
    if BeautifulSoup:
        try:
            soup = BeautifulSoup(html, 'html.parser')
            for slide in soup.select('.hero-slide'):
                link = slide.select_one('.hero-poster[href]') or slide.select_one('.btn-primary[href]')
                poster = soup_attr(slide.select_one('.hero-poster img'), 'src')
                fanart = style_background_url(soup_attr(slide.select_one('.hero-bg'), 'style'))
                chips = [soup_text(chip) for chip in slide.select('.hero-meta .chip')]
                item = {
                    'url': cinehay_url(soup_attr(link, 'href')),
                    'title': soup_text(slide.select_one('.hero-title')),
                    'original': soup_text(slide.select_one('.hero-original')),
                    'poster': cinehay_url(poster) if poster else CINEHAY_ICON,
                    'fanart': cinehay_url(fanart) if fanart else (cinehay_url(poster) if poster else CINEHAY_ICON),
                    'quality': chips[0] if chips else '',
                    'episode': next((chip for chip in chips if 'tập' in chip.lower() or 'full' in chip.lower() or 'hoàn' in chip.lower()), ''),
                    'duration': next((chip for chip in chips if 'phút' in chip.lower()), ''),
                    'plot': soup_text(slide.select_one('.hero-desc'))
                }
                if item.get('url') and item.get('title'):
                    movies.append(item)
            return movies
        except Exception as error:
            log_error(f'Không parse được hero CineHay: {error}')
    for block in re.findall(r'<article[^>]+class=["\'][^"\']*hero-slide[^"\']*["\'][^>]*>(.*?)</article>', html, re.I | re.S):
        poster = first_regex(block, r'<a[^>]+class=["\'][^"\']*hero-poster[^"\']*["\'][^>]*>.*?<img[^>]+src=["\']([^"\']+)')
        fanart = style_background_url(first_regex(block, r'<div[^>]+class=["\'][^"\']*hero-bg[^"\']*["\'][^>]+style=["\']([^"\']+)'))
        chips = [html_text(chip) for chip in re.findall(r'<span[^>]+class=["\'][^"\']*chip[^"\']*["\'][^>]*>(.*?)</span>', block, re.I | re.S)]
        item = {
            'url': cinehay_url(first_regex(block, r'<a[^>]+class=["\'][^"\']*(?:hero-poster|btn-primary)[^"\']*["\'][^>]+href=["\']([^"\']+)')),
            'title': html_text(first_regex(block, r'<h1[^>]+class=["\'][^"\']*hero-title[^"\']*["\'][^>]*>(.*?)</h1>')),
            'original': html_text(first_regex(block, r'<div[^>]+class=["\'][^"\']*hero-original[^"\']*["\'][^>]*>(.*?)</div>')),
            'poster': cinehay_url(poster) if poster else CINEHAY_ICON,
            'fanart': cinehay_url(fanart) if fanart else (cinehay_url(poster) if poster else CINEHAY_ICON),
            'quality': chips[0] if chips else '',
            'episode': next((chip for chip in chips if 'tập' in chip.lower() or 'full' in chip.lower() or 'hoàn' in chip.lower()), ''),
            'duration': next((chip for chip in chips if 'phút' in chip.lower()), ''),
            'plot': html_text(first_regex(block, r'<p[^>]+class=["\'][^"\']*hero-desc[^"\']*["\'][^>]*>(.*?)</p>'))
        }
        if item.get('url') and item.get('title'):
            movies.append(item)
    return movies


def parse_movies(html, include_hero=False):
    movies = parse_hero(html) if include_hero else []
    if BeautifulSoup:
        try:
            soup = BeautifulSoup(html, 'html.parser')
            movies.extend([parse_card(card) for card in soup.select('a.movie-card[href]')])
        except Exception as error:
            log_error(f'Không parse được danh sách phim: {error}')
    else:
        for match in re.finditer(r'<a\s+class=["\'][^"\']*movie-card[^"\']*["\'](?P<attrs>[^>]*)>(?P<body>.*?)</a>', html, re.I | re.S):
            movies.append(parse_card((match.group('attrs'), match.group('body'))))
    unique = []
    seen = set()
    for item in movies:
        key = movie_key(item.get('url'))
        if key and key not in seen:
            seen.add(key)
            unique.append(item)
    return unique


def parse_detail(html, source_url=''):
    detail = {
        'url': cinehay_url(source_url),
        'title': '',
        'original': '',
        'poster': '',
        'fanart': '',
        'plot': '',
        'quality': '',
        'episode': '',
        'duration': '',
        'year': 0,
        'genre': '',
        'country': '',
        'director': '',
        'cast': '',
        'media_type': 'movie'
    }
    if BeautifulSoup:
        try:
            soup = BeautifulSoup(html, 'html.parser')
            poster = soup_attr(soup.select_one('.detail-poster img'), 'src')
            fanart = style_background_url(soup_attr(soup.select_one('.detail-hero-bg'), 'style'))
            chips = [soup_text(chip) for chip in soup.select('.detail-meta .chip')]
            detail.update({
                'title': soup_text(soup.select_one('.detail-title')),
                'original': soup_text(soup.select_one('.detail-original')),
                'poster': cinehay_url(poster) if poster else '',
                'fanart': cinehay_url(fanart) if fanart else '',
                'plot': soup_text(soup.select_one('.detail-desc')),
                'quality': chips[0] if chips else '',
                'episode': next((chip for chip in chips if 'tập' in chip.lower() or 'full' in chip.lower() or 'hoàn' in chip.lower()), ''),
                'duration': next((chip for chip in chips if 'phút' in chip.lower()), ''),
                'year': next((year_from_text(chip) for chip in chips if year_from_text(chip)), 0),
                'media_type': 'tvshow' if 'bộ' in soup_text(soup.select_one('.detail-eyebrow')).lower() else 'movie'
            })
            for dt in soup.select('.detail-info dt'):
                key = soup_text(dt).lower()
                dd = dt.find_next_sibling('dd')
                value = soup_text(dd)
                if 'đạo diễn' in key:
                    detail['director'] = value
                elif 'diễn viên' in key:
                    detail['cast'] = value
                elif 'thể loại' in key:
                    detail['genre'] = value
                elif 'quốc gia' in key:
                    detail['country'] = value
            detail['poster'] = detail.get('poster') or meta_content(html, 'og:image') or CINEHAY_ICON
            detail['fanart'] = detail.get('fanart') or meta_content(html, 'og:image') or detail.get('poster') or CINEHAY_ICON
            detail['title'] = detail.get('title') or html_text(meta_content(html, 'og:title').replace('| CINEHAY', ''))
            detail['plot'] = detail.get('plot') or html_text(meta_content(html, 'og:description'))
            return detail
        except Exception as error:
            log_error(f'Không parse được chi tiết phim: {error}')
    poster = first_regex(html, r'<div[^>]+class=["\'][^"\']*detail-poster[^"\']*["\'][^>]*>.*?<img[^>]+src=["\']([^"\']+)')
    fanart = style_background_url(first_regex(html, r'<div[^>]+class=["\'][^"\']*detail-hero-bg[^"\']*["\'][^>]+style=["\']([^"\']+)'))
    chips = [html_text(chip) for chip in re.findall(r'<span[^>]+class=["\'][^"\']*chip[^"\']*["\'][^>]*>(.*?)</span>', html, re.I | re.S)]
    detail.update({
        'title': html_text(first_regex(html, r'<h1[^>]+class=["\'][^"\']*detail-title[^"\']*["\'][^>]*>(.*?)</h1>')),
        'original': html_text(first_regex(html, r'<div[^>]+class=["\'][^"\']*detail-original[^"\']*["\'][^>]*>(.*?)</div>')),
        'poster': cinehay_url(poster) if poster else meta_content(html, 'og:image') or CINEHAY_ICON,
        'fanart': cinehay_url(fanart) if fanart else meta_content(html, 'og:image') or CINEHAY_ICON,
        'plot': html_text(first_regex(html, r'<p[^>]+class=["\'][^"\']*detail-desc[^"\']*["\'][^>]*>(.*?)</p>')),
        'quality': chips[0] if chips else '',
        'episode': next((chip for chip in chips if 'tập' in chip.lower() or 'full' in chip.lower() or 'hoàn' in chip.lower()), ''),
        'duration': next((chip for chip in chips if 'phút' in chip.lower()), ''),
        'year': next((year_from_text(chip) for chip in chips if year_from_text(chip)), 0),
        'media_type': 'tvshow' if 'Phim bộ' in html else 'movie'
    })
    return detail


def is_resolvable_embed(url):
    url = clean_text(url).lower()
    return 'opstream' in url or 'player.phimapi.com/player/' in url


def dedupe_episodes(episodes):
    unique = []
    seen = set()
    for episode in episodes:
        key = (episode.get('group_key'), episode.get('name'), episode.get('stream'))
        if key in seen:
            continue
        seen.add(key)
        unique.append(episode)
    return unique


def parse_episodes(html):
    episodes = []
    if BeautifulSoup:
        try:
            soup = BeautifulSoup(html, 'html.parser')
            source_labels = {}
            for index, tab in enumerate(soup.select('#sourceTabs .source-tab')):
                source_id = soup_attr(tab, 'data-source') or str(index)
                source_labels[source_id] = soup_text(tab) or f'Server {index + 1}'
            for pane in soup.select('.source-pane'):
                source_id = soup_attr(pane, 'data-source') or '0'
                source_label = source_labels.get(source_id, f'Server {source_id}')
                server_panes = pane.select('.episode-section > .server-pane') or pane.select('.server-pane')
                for index, server in enumerate(server_panes):
                    server_id = soup_attr(server, 'data-server') or str(index)
                    span_label = soup_text(server.select_one('h3 span'))
                    heading = soup_text(server.select_one('h3'))
                    server_label = span_label or heading.replace('Danh sách tập', '').replace('—', '').strip() or source_label
                    group_label = source_label if server_label == source_label else f'{source_label} - {server_label}'
                    for btn in server.select('.episode-btn'):
                        m3u8 = soup_attr(btn, 'data-m3u8')
                        embed = soup_attr(btn, 'data-embed')
                        stream = cinehay_url(m3u8) if m3u8 else (embed if is_resolvable_embed(embed) else '')
                        if not stream:
                            continue
                        name = soup_attr(btn, 'data-name') or soup_text(btn) or 'Full'
                        episodes.append({
                            'name': name,
                            'stream': stream,
                            'embed': embed,
                            'source': source_label,
                            'server': server_label,
                            'group_key': f'{source_id}:{server_id}',
                            'group_label': group_label
                        })
            return dedupe_episodes(episodes)
        except Exception as error:
            log_error(f'Không parse được tập phim: {error}')
    for index, match in enumerate(re.finditer(r'<button[^>]+class=["\'][^"\']*episode-btn[^"\']*["\'](?P<attrs>[^>]*)>(?P<body>.*?)</button>', html, re.I | re.S)):
        attrs = match.group('attrs')
        m3u8 = html_attr(attrs, 'data-m3u8')
        embed = html_attr(attrs, 'data-embed')
        stream = cinehay_url(m3u8) if m3u8 else (embed if is_resolvable_embed(embed) else '')
        if not stream:
            continue
        name = html_attr(attrs, 'data-name') or html_text(match.group('body')) or f'Tập {index + 1}'
        episodes.append({
            'name': name,
            'stream': stream,
            'embed': embed,
            'source': 'CineHay',
            'server': 'Server',
            'group_key': '0:0',
            'group_label': 'CineHay'
        })
    return dedupe_episodes(episodes)


def episode_groups(episodes):
    groups = OrderedDict()
    for episode in episodes:
        key = episode.get('group_key') or '0:0'
        if key not in groups:
            groups[key] = {'label': episode.get('group_label') or 'CineHay', 'items': []}
        groups[key]['items'].append(episode)
    return groups


def parse_next_page(html):
    if BeautifulSoup:
        try:
            soup = BeautifulSoup(html, 'html.parser')
            for link in soup.select('nav.pagination a.page-item[href]'):
                if soup_text(link) in ('›', '>', 'Sau', 'Next'):
                    return cinehay_url(soup_attr(link, 'href'))
        except:
            pass
    match = re.search(r'<a[^>]+class=["\'][^"\']*page-item[^"\']*["\'][^>]+href=["\']([^"\']+)["\'][^>]*>\s*(?:›|&rsaquo;|&gt;)\s*</a>', html, re.I | re.S)
    return cinehay_url(match.group(1)) if match else ''


def resolve_stream(url, referer=''):
    url = html_unescape(clean_text(url))
    if not url:
        return ''
    parsed = urlparse(url)
    query_url = parse_qs(parsed.query).get('url', [''])[0]
    if query_url and '.m3u8' in query_url:
        return html_unescape(query_url)
    if '.m3u8' in url:
        return url
    html = get_text(url, referer or CINEHAY_BASE)
    stream = first_regex(html, r'const\s+url\s*=\s*["\']([^"\']+\.m3u8[^"\']*)')
    if not stream:
        stream = first_regex(html, r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\']')
    if not stream:
        stream = first_regex(html, r'file\s*:\s*["\']([^"\']+\.m3u8[^"\']*)')
    return urljoin(url, stream) if stream else ''


def stream_with_headers(url, referer=''):
    headers = {'User-Agent': HEADERS['User-Agent'], 'Referer': referer or CINEHAY_BASE}
    return f'{url}|{urlencode(headers)}'


def render_menu():
    setContent(HANDLE, 'videos')
    add_nav('[COLOR red]Tìm kiếm[/COLOR]', get_url(mode='search'), 'Tìm phim theo tên tiếng Việt hoặc tiếng Anh')
    for title, path in LISTINGS.items():
        add_nav(title, get_url(mode='list', path=path, title=title), f'Duyệt {title}')
    add_nav('Thể loại', get_url(mode='submenu', group='genres'), 'Duyệt phim theo thể loại')
    add_nav('Quốc gia', get_url(mode='submenu', group='countries'), 'Duyệt phim theo quốc gia')
    add_nav('Năm phát hành', get_url(mode='submenu', group='years'), 'Duyệt phim theo năm')
    endOfDirectory(HANDLE)


def render_submenu(group):
    setContent(HANDLE, 'videos')
    data = GENRES if group == 'genres' else COUNTRIES if group == 'countries' else YEARS
    for title, path in data.items():
        add_nav(title, get_url(mode='list', path=path, title=title), f'Duyệt {title}')
    endOfDirectory(HANDLE)


def render_search():
    query = xbmcgui.Dialog().input('Tìm phim trên CineHay', type=xbmcgui.INPUT_ALPHANUM)
    query = clean_text(query)
    if not query:
        endOfDirectory(HANDLE, succeeded=False)
        return
    render_listing(f'tim-kiem?q={quote_plus(query)}', f'Tìm: {query}')


def render_listing(path='index.php', title='CineHay', page=1):
    url = page_url(path, page)
    html = get_text(url)
    include_hero = url.rstrip('/').endswith('index.php') or url.rstrip('/') == CINEHAY_BASE.rstrip('/')
    movies = parse_movies(html, include_hero)
    setContent(HANDLE, 'movies')
    for item in movies:
        add_item(
            item,
            get_url(mode='detail', url=item.get('url')),
            True,
            movie_label(item),
            'tvshow' if item.get('episode') and item.get('episode') != 'FULL' else 'movie'
        )
    next_url = parse_next_page(html)
    if next_url:
        add_item(
            {'title': 'Trang tiếp theo', 'poster': CINEHAY_ICON, 'plot': f'Xem thêm {title}'},
            get_url(mode='list', path=next_url, title=title),
            True,
            '[COLOR yellow]Trang tiếp theo[/COLOR]',
            'video'
        )
    if not movies:
        add_nav('Không có phim', get_url(mode='noop'), title, addon_icon)
    endOfDirectory(HANDLE)


def render_detail(url, group_key=''):
    url = cinehay_url(url)
    html = get_text(url)
    detail = parse_detail(html, url)
    episodes = parse_episodes(html)
    groups = episode_groups(episodes)
    setContent(HANDLE, 'episodes' if group_key else 'videos')
    if group_key:
        selected = groups.get(group_key, {'items': []}).get('items') or []
        for episode in selected:
            label = f'{detail.get("title") or "CineHay"} - {episode.get("name")}'
            item = dict(detail)
            item['title'] = label
            item['plot'] = '\n'.join(part for part in (plot_text(detail), f'Server: {episode.get("group_label")}') if part)
            add_item(
                item,
                get_url(mode='play', url=episode.get('stream'), title=label, poster=detail.get('poster'), referer=url),
                False,
                episode.get('name'),
                'episode'
            )
    elif len(groups) > 1:
        for key, group in groups.items():
            item = dict(detail)
            item['title'] = group.get('label')
            item['plot'] = '\n'.join(part for part in (plot_text(detail), f'{len(group.get("items") or [])} tập/link phát') if part)
            add_item(
                item,
                get_url(mode='detail', url=url, group=key),
                True,
                f'{group.get("label")} [COLOR gray]({len(group.get("items") or [])})[/COLOR]',
                detail.get('media_type') or 'tvshow'
            )
    else:
        only_group = next(iter(groups.values()), {'items': []})
        for episode in only_group.get('items') or []:
            label = f'{detail.get("title") or "CineHay"} - {episode.get("name")}'
            item = dict(detail)
            item['title'] = label
            item['plot'] = '\n'.join(part for part in (plot_text(detail), f'Server: {episode.get("group_label")}') if part)
            add_item(
                item,
                get_url(mode='play', url=episode.get('stream'), title=label, poster=detail.get('poster'), referer=url),
                False,
                episode.get('name'),
                'episode'
            )
    if not episodes:
        add_nav('Chưa tìm thấy link phát HLS', get_url(mode='noop'), detail.get('title') or url, addon_icon)
    endOfDirectory(HANDLE)


def render_play(url, title='', poster='', referer=''):
    stream = resolve_stream(url, referer)
    if not stream:
        notify('Không lấy được link phát')
        setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    poster = poster or CINEHAY_ICON
    list_item = xbmcgui.ListItem(path=stream_with_headers(stream, referer))
    list_item.setProperty('IsPlayable', 'true')
    list_item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': poster})
    try:
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
    except:
        pass
    set_video_info(list_item, {'title': title or 'CineHay', 'poster': poster, 'plot': stream}, 'episode')
    setResolvedUrl(HANDLE, True, list_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    mode = params.get('mode', '')
    if not mode:
        render_menu()
    elif mode == 'search':
        render_search()
    elif mode == 'submenu':
        render_submenu(params.get('group', 'genres'))
    elif mode == 'list':
        render_listing(params.get('path', 'index.php'), params.get('title', 'CineHay'), get_int(params.get('page'), 1))
    elif mode == 'detail':
        render_detail(params.get('url', ''), params.get('group', ''))
    elif mode == 'play':
        render_play(params.get('url', ''), params.get('title', ''), params.get('poster', ''), params.get('referer', ''))
    elif mode == 'noop':
        endOfDirectory(HANDLE, succeeded=False)
    else:
        raise ValueError(f'Tham số {paramstring} không hợp lệ')


if __name__ == '__main__':
    router(sys.argv[2][1:])

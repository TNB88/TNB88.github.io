from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from xbmcaddon import Addon
import base64
import http.client
import os
import ssl
import threading
import xbmc

try:
    import xbmcvfs
except:
    xbmcvfs = None

ADDON_ID = 'plugin.video.cinehay'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
PORTS = list(range(49771, 49791))
TIMEOUT = 20


def log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log(f'CineHay proxy: {message}', level)
    except:
        pass


def profile_dir():
    addon = Addon(ADDON_ID)
    path = addon.getAddonInfo('profile')
    if xbmcvfs:
        path = xbmcvfs.translatePath(path)
    if path.startswith('special://'):
        path = os.path.join(os.path.dirname(__file__), 'resources', 'profile')
    os.makedirs(path, exist_ok=True)
    return path


def write_port(port):
    try:
        with open(os.path.join(profile_dir(), 'streamc_proxy_port.txt'), 'w', encoding='utf-8') as output:
            output.write(str(port))
    except Exception as error:
        log(f'cannot write port: {error}', xbmc.LOGWARNING)


def b64url_decode(value):
    value = (value or '').strip()
    value += '=' * ((4 - len(value) % 4) % 4)
    return base64.urlsafe_b64decode(value.encode('ascii')).decode('utf-8', 'replace')


def fetch_remote(url, referer, range_header=''):
    parsed = urlparse(url)
    path = parsed.path or '/'
    if parsed.query:
        path += '?' + parsed.query
    connection_class = http.client.HTTPSConnection if parsed.scheme == 'https' else http.client.HTTPConnection
    kwargs = {'timeout': TIMEOUT}
    if parsed.scheme == 'https':
        kwargs['context'] = ssl.create_default_context()
    connection = connection_class(parsed.netloc, **kwargs)
    headers = {
        'Host': parsed.netloc,
        'User-Agent': USER_AGENT,
        'Accept': '*/*',
        'Referer': referer,
        'Connection': 'close'
    }
    if range_header:
        headers['Range'] = range_header
    try:
        connection.request('GET', path, headers=headers)
        response = connection.getresponse()
        body = response.read()
        response_headers = {name.lower(): value for name, value in response.getheaders()}
        return response.status, response_headers, body
    finally:
        try:
            connection.close()
        except:
            pass


class CineHayProxyHandler(BaseHTTPRequestHandler):
    server_version = 'CineHayProxy/1.0'

    def log_message(self, fmt, *args):
        return

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/ping':
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Content-Length', '7')
            self.end_headers()
            self.wfile.write(b'cinehay')
            return
        if parsed.path not in ('/seg', '/seg.ts'):
            self.send_error(404)
            return
        try:
            query = parse_qs(parsed.query)
            url = b64url_decode((query.get('u') or [''])[0])
            referer = b64url_decode((query.get('r') or [''])[0])
            if not url:
                self.send_error(400)
                return
            status, headers, body = fetch_remote(url, referer, self.headers.get('Range', ''))
            self.send_response(status)
            content_type = headers.get('content-type') or ''
            if urlparse(url).path.lower().endswith(('.png', '.ts')) or body[:1] == b'\x47':
                content_type = 'video/mp2t'
            if not content_type:
                content_type = 'application/octet-stream'
            self.send_header('Content-Type', content_type)
            for name in ('content-length', 'content-range', 'accept-ranges'):
                if headers.get(name):
                    self.send_header(name.title(), headers.get(name))
            self.end_headers()
            self.wfile.write(body)
        except Exception as error:
            log(f'proxy segment error: {error}', xbmc.LOGERROR)
            try:
                self.send_error(502)
            except:
                pass


def create_server():
    for port in PORTS:
        try:
            server = ThreadingHTTPServer(('127.0.0.1', port), CineHayProxyHandler)
            write_port(port)
            log(f'started on port {port}')
            return server
        except OSError:
            continue
    return None


def main():
    server = create_server()
    if not server:
        log('no free port for proxy', xbmc.LOGERROR)
        return
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()
    monitor = xbmc.Monitor()
    try:
        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break
    finally:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    main()

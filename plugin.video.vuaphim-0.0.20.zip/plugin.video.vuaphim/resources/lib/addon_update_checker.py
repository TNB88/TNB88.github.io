# -*- coding: utf-8 -*-

def check_update():
    return

# -*- coding: utf-8 -*-
import sys
import re
import requests
from urllib.parse import urlencode, parse_qsl, urlparse, urljoin, quote_plus, unquote
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin

_url = sys.argv[0]
_handle = int(sys.argv[1])

ADDON_NAME = 'VUA PHIM'
addon = xbmcaddon.Addon()

HOME_PAGE = (addon.getSetting('home_page').strip() or 'https://forum.timfshare.com').rstrip('/')

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0'
HEADERS = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'vi,en-US;q=0.8,en;q=0.5',
}

UA_FSHARE_API = 'thuviencine-FSWXQQ'
APP_KEY_FSHARE_API = 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt'
FSHARE_FOLDER_PAGE_SIZE = 50
LINKS_PAGE_SIZE = 25
FSHARE_NAME_WORKERS = 6


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[VUA PHIM] {}'.format(msg), level)


def get_url(**kwargs):
    return '{}?{}'.format(_url, urlencode(kwargs))


def request_html(url):
    r = requests.get(url, headers=HEADERS, timeout=20, allow_redirects=True)
    r.raise_for_status()
    return r.text


def clean_text(text):
    return re.sub(r'\s+', ' ', text or '').strip()


def get_fshare_linkcode(url):
    path = urlparse(url).path
    parts = [p for p in path.split('/') if p]
    return parts[-1] if parts else ''



def multi_unquote(value, rounds=4):
    result = value or ''
    for _ in range(rounds):
        try:
            decoded = unquote(result)
        except Exception:
            break
        if decoded == result:
            break
        result = decoded
    return result


def collect_fshare_urls_from_value(value):
    """
    Extract Fshare URLs from:
    - direct fshare links
    - encoded fshare links
    - middle links like view.vietmediaf.store/?url=encoded_fshare
    """
    found = []
    seen = set()

    def add(raw_value):
        if not raw_value:
            return

        raw_value = str(raw_value).replace('&amp;', '&')
        decoded_value = multi_unquote(raw_value)

        for text in (raw_value, decoded_value):
            matches = re.findall(
                r'https?://(?:www\.)?fshare\.vn/(?:file|folder)/[A-Za-z0-9]+',
                text
            )

            for m in matches:
                m = m.split('?')[0].strip()
                if m and m not in seen:
                    seen.add(m)
                    found.append(m)

    add(value)

    # If middle URL has query params, scan every query value
    for candidate in (value or '', multi_unquote(value or '')):
        try:
            parsed = urlparse(candidate)
            pairs = parse_qsl(parsed.query, keep_blank_values=True)
            for _k, v in pairs:
                add(v)
        except Exception:
            pass

    return found


def make_fshare_link_item(fshare_url, name=''):
    fshare_url = multi_unquote(fshare_url).split('?')[0].strip()
    linkcode = get_fshare_linkcode(fshare_url)

    if not linkcode:
        return None

    is_folder = '/folder/' in fshare_url

    if not name or 'fshare.vn' in name.lower() or 'vietmediaf' in name.lower():
        name = 'Fshare Folder - {}'.format(linkcode) if is_folder else 'Fshare File - {}'.format(linkcode)

    return {
        'name': name,
        'url': fshare_url,
        'linkcode': linkcode,
        'is_folder': is_folder
    }


FORUM_CACHE = {}


def get_forum_path_by_name(target_name):
    """
    Resolve subforum path dynamically from /forums/phim-anh.3/
    because node IDs/slugs can differ.
    """
    key = target_name.lower()

    if key in FORUM_CACHE:
        return FORUM_CACHE[key]

    try:
        html = request_html(HOME_PAGE + '/forums/phim-anh.3/')
        soup = BeautifulSoup(html, 'html.parser')

        for a in soup.select('a[href*="/forums/"]'):
            text = clean_text(a.get_text(' ', strip=True))
            href = a.get('href', '')

            if not text or not href:
                continue

            text_low = text.lower()
            wanted = key

            ok = False

            if wanted == 'bluray remux nguyên gốc':
                ok = ('bluray' in text_low or 'remux' in text_low)
            elif wanted == 'non-hd':
                ok = ('non-hd' in text_low or 'non hd' in text_low)
            elif wanted == 'hd':
                ok = (text_low.strip() == 'hd')
            elif wanted == '3d':
                ok = (text_low.strip() == '3d')
            elif wanted == '4k':
                ok = (text_low.strip() == '4k')
            else:
                ok = wanted in text_low

            if not ok:
                continue

            parsed = urlparse(urljoin(HOME_PAGE + '/', href))
            path = parsed.path

            if path:
                FORUM_CACHE[key] = path
                return path

    except Exception as e:
        log('Resolve forum path error: {}'.format(e), xbmc.LOGERROR)

    return ''


def format_size(bytes_size):
    try:
        size = float(bytes_size)
    except Exception:
        size = 0
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    i = 0
    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1
    return '{:.1f} {}'.format(size, units[i])


def set_video_info(li, title='', plot='', image=''):
    if image:
        li.setArt({'thumb': image, 'icon': image, 'poster': image, 'fanart': image})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setPlot(plot)
        tag.setMediaType('movie')
    except Exception:
        li.setInfo('video', {'title': title, 'plot': plot, 'mediatype': 'movie'})


def list_categories():
    cats = [
        ('Phim ảnh - tất cả', '/forums/phim-anh.3/'),
        ('non-HD', 'resolve:non-HD'),
        ('HD', 'resolve:HD'),
        ('Bluray Remux nguyên gốc', 'resolve:Bluray Remux nguyên gốc'),
        ('3D', 'resolve:3D'),
        ('4K', 'resolve:4K'),
        ('Tìm kiếm', 'search'),
    ]

    for name, path in cats:
        li = xbmcgui.ListItem(label=name)

        try:
            li.setInfo('video', {'title': name})
        except Exception:
            pass

        xbmcplugin.addDirectoryItem(
            _handle,
            get_url(action='threads', category=path, page='1'),
            li,
            True
        )

    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.endOfDirectory(_handle, succeeded=True)


def build_category_url(category, page=1, query=''):
    if category.startswith('resolve:'):
        resolved = get_forum_path_by_name(category.replace('resolve:', '', 1))
        if resolved:
            category = resolved
        else:
            category = '/forums/phim-anh.3/'

    if category == 'search':
        if page <= 1:
            return HOME_PAGE + '/search/search?keywords={}&title_only=1'.format(quote_plus(query))
        return HOME_PAGE + '/search/search?keywords={}&title_only=1&page={}'.format(quote_plus(query), page)

    base = urljoin(HOME_PAGE + '/', category.lstrip('/'))

    if page <= 1:
        return base

    return base.rstrip('/') + '/page-{}'.format(page)


def get_threads(category, page=1, query=''):
    if category == 'search' and not query:
        kb = xbmc.Keyboard('', 'Nhập tên phim cần tìm')
        kb.doModal()
        if not kb.isConfirmed():
            return [], ''
        query = kb.getText().strip()
        if not query:
            return [], ''

    url = build_category_url(category, page, query)

    try:
        html = request_html(url)
    except Exception as e:
        log('Get threads error: {}'.format(e), xbmc.LOGERROR)
        return [], query

    soup = BeautifulSoup(html, 'html.parser')
    threads = []
    added = set()

    nodes = (
        soup.select('div.structItem--thread')
        or soup.select('div.structItem')
        or soup.select('li.block-row')
    )

    for node in nodes:
        a = (
            node.select_one('a[data-tp-primary="on"]')
            or node.select_one('.structItem-title a')
            or node.select_one('a[href*="/threads/"]')
        )

        if not a:
            continue

        href = a.get('href', '')
        title = clean_text(a.get_text(' ', strip=True))

        if not href or not title or '/threads/' not in href:
            continue

        thread_url = urljoin(HOME_PAGE + '/', href)

        if thread_url in added:
            continue
        added.add(thread_url)

        thumb = ''
        img = node.select_one('img[src], img[data-src], img[data-url]')
        if img:
            thumb = img.get('data-url') or img.get('data-src') or img.get('src') or ''
            thumb = urljoin(HOME_PAGE + '/', thumb)

        plot = clean_text(node.get_text(' ', strip=True))[:700]

        threads.append({
            'name': title,
            'url': thread_url,
            'plot': plot,
            'thumb': thumb
        })

    return threads, query


def list_threads(category, page=1, query=''):
    try:
        threads, query = get_threads(category, page, query)
    except Exception as e:
        log('list_threads fatal error: {}'.format(e), xbmc.LOGERROR)
        li = xbmcgui.ListItem(label='[COLOR red][B]Lỗi mở mục: {}[/B][/COLOR]'.format(e))
        xbmcplugin.addDirectoryItem(_handle, '', li, False)
        xbmcplugin.endOfDirectory(_handle, succeeded=True)
        return

    if not threads:
        li = xbmcgui.ListItem(label='[COLOR red][B]Không tìm thấy phim hoặc sai đường dẫn mục[/B][/COLOR]')
        xbmcplugin.addDirectoryItem(_handle, '', li, False)

        try:
            debug_url = build_category_url(category, page, query)
            debug_li = xbmcgui.ListItem(label='[COLOR gray]URL: {}[/COLOR]'.format(debug_url))
            xbmcplugin.addDirectoryItem(_handle, '', debug_li, False)
        except Exception:
            pass

        xbmcplugin.endOfDirectory(_handle, succeeded=True)
        return

    for t in threads:
        li = xbmcgui.ListItem(label=t['name'])
        set_video_info(li, t['name'], t.get('plot', ''), t.get('thumb', ''))
        url = get_url(action='links', thread=t['url'])
        xbmcplugin.addDirectoryItem(_handle, url, li, True)

    next_li = xbmcgui.ListItem(label='[COLOR yellow][B]» Trang Tiếp Theo «[/B][/COLOR]')
    next_url = get_url(
        action='threads',
        category=category,
        page=str(page + 1),
        query=query
    )
    xbmcplugin.addDirectoryItem(_handle, next_url, next_li, True)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle, succeeded=True)


def make_plot_from_content(content):
    if not content:
        return ''

    raw = content.get_text('\n', strip=True)
    lines = []

    for line in raw.split('\n'):
        line = clean_text(line)
        if not line:
            continue

        low = line.lower()

        if 'fshare.vn/' in low:
            continue

        if low in ('like', 'reply', 'quote', 'report', 'edit'):
            continue

        lines.append(line)

    return '\n'.join(lines)[:8000]


def parse_thread_detail(thread_url):
    try:
        html = request_html(thread_url)
    except Exception as e:
        log('Thread detail error: {}'.format(e), xbmc.LOGERROR)
        return {'title': '', 'plot': '', 'image': '', 'links': []}

    soup = BeautifulSoup(html, 'html.parser')

    title_el = soup.select_one('h1.p-title-value') or soup.select_one('h1')
    title = clean_text(title_el.get_text(' ', strip=True)) if title_el else ''

    content = (
        soup.select_one('article.message--post .bbWrapper')
        or soup.select_one('.message-body .bbWrapper')
        or soup.select_one('.bbWrapper')
        or soup.select_one('article.message-body')
        or soup.select_one('.message-content')
    )

    plot = ''
    image = ''

    if content:
        for bad in content.select('script, style, noscript'):
            bad.decompose()

        plot = make_plot_from_content(content)

        img = (
            content.select_one('img.bbImage[src], img.bbImage[data-src], img.bbImage[data-url]')
            or content.select_one('img[src], img[data-src], img[data-url]')
        )

        if img:
            image = img.get('data-url') or img.get('data-src') or img.get('src') or ''
            image = urljoin(HOME_PAGE + '/', image)

    links = []
    added = set()

    def add_fshare_url(fshare_url, label=''):
        item = make_fshare_link_item(fshare_url, label)

        if not item:
            return

        key = item['url']

        if key in added:
            return

        added.add(key)
        links.append(item)

    # 1. Scan href and link attributes, including middle links.
    for a in soup.select('a[href]'):
        href = a.get('href', '').strip()
        label = clean_text(a.get_text(' ', strip=True))

        if href:
            absolute_href = urljoin(thread_url, href)

            for f_url in collect_fshare_urls_from_value(absolute_href):
                add_fshare_url(f_url, label)

        for attr in ('title', 'data-href', 'data-url', 'data-target'):
            val = a.get(attr, '')

            for f_url in collect_fshare_urls_from_value(val):
                add_fshare_url(f_url, label)

    # 2. Scan decoded raw HTML.
    decoded_html = multi_unquote(html)

    for f_url in collect_fshare_urls_from_value(decoded_html):
        add_fshare_url(f_url, '')

    # 3. Scan visible text.
    visible_text = soup.get_text('\n', strip=True)
    decoded_text = multi_unquote(visible_text)

    for f_url in collect_fshare_urls_from_value(decoded_text):
        add_fshare_url(f_url, '')

    return {'title': title, 'plot': plot, 'image': image, 'links': links}



def get_fshare_current_info_fast(linkcode):
    """
    Fast current info lookup for one Fshare linkcode.
    Used only for the current visible page, not all 300+ links.
    """
    if not linkcode:
        return {}

    try:
        api_url = (
            'https://www.fshare.vn/api/v3/files/folder'
            '?linkcode={}&sort=type,name&page=1&per-page=1'
        ).format(linkcode)

        r = requests.get(
            api_url,
            headers={'User-Agent': UA_FSHARE_API, 'Accept': 'application/json'},
            timeout=5
        )

        r.raise_for_status()

        data = r.json()
        current = data.get('current', {})

        if not isinstance(current, dict):
            return {}

        return {
            'name': current.get('name', ''),
            'type': current.get('type', 0),
            'size': current.get('size', 0)
        }

    except Exception as e:
        log('Fshare current info error: {}'.format(e), xbmc.LOGERROR)
        return {}


def enrich_one_fshare_item(item):
    """
    Replace generic names like Fshare Folder - CODE with real Fshare folder/file name.
    """
    if not item:
        return item

    name = item.get('name', '')
    linkcode = item.get('linkcode', '')

    is_generic = (
        not name
        or name.startswith('Fshare Folder - ')
        or name.startswith('Fshare File - ')
        or name.startswith('Fshare - ')
    )

    if not is_generic:
        return item

    info = get_fshare_current_info_fast(linkcode)
    real_name = info.get('name', '')

    if real_name:
        item = dict(item)
        item['name'] = real_name

        if info.get('type') == 1:
            item['is_folder'] = False

            size = info.get('size', 0)

            if size:
                item['name'] = '{} [COLOR yellow]| {}[/COLOR]'.format(
                    real_name,
                    format_size(size)
                )

    return item


def enrich_fshare_items_page(items):
    """
    Enrich only current page items concurrently.
    This avoids long spinning on posts with hundreds of Fshare folders.
    """
    if not items:
        return items

    result = list(items)

    with ThreadPoolExecutor(max_workers=FSHARE_NAME_WORKERS) as executor:
        future_map = {
            executor.submit(enrich_one_fshare_item, item): index
            for index, item in enumerate(result)
        }

        for future in as_completed(future_map):
            index = future_map[future]

            try:
                result[index] = future.result()
            except Exception:
                pass

    return result



def list_links(thread_url, page=1):
    detail = parse_thread_detail(thread_url)

    links = detail.get('links', [])
    plot = detail.get('plot', '')
    image = detail.get('image', '')
    title = detail.get('title', '')

    if not links:
        li = xbmcgui.ListItem(label='[COLOR red][B]Không thấy link Fshare trong bài[/B][/COLOR]')
        set_video_info(li, title or 'Không thấy link Fshare', plot, image)
        xbmcplugin.addDirectoryItem(_handle, '', li, False)
        xbmcplugin.endOfDirectory(_handle, succeeded=True)
        return

    total = len(links)
    page = max(1, int(page))
    start = (page - 1) * LINKS_PAGE_SIZE
    end = start + LINKS_PAGE_SIZE

    page_links = links[start:end]

    # Only enrich current visible page to avoid loading hundreds of folder names.
    page_links = enrich_fshare_items_page(page_links)

    if page > 1:
        back_li = xbmcgui.ListItem(label='[COLOR yellow][B]« Trang Trước[/B][/COLOR]')
        back_url = get_url(action='links', thread=thread_url, page=str(page - 1))
        xbmcplugin.addDirectoryItem(_handle, back_url, back_li, True)

    for v in page_links:
        li = xbmcgui.ListItem(label=v['name'])
        set_video_info(li, title or v['name'], plot, image)

        if v['is_folder']:
            url = get_url(
                action='fshare_folder',
                linkcode=v['linkcode'],
                page='1',
                title=title,
                image=image
            )
            xbmcplugin.addDirectoryItem(_handle, url, li, True)
        else:
            li.setProperty('IsPlayable', 'true')
            url = get_url(action='play_fshare', linkcode=v['linkcode'])
            xbmcplugin.addDirectoryItem(_handle, url, li, False)

    if end < total:
        next_li = xbmcgui.ListItem(
            label='[COLOR yellow][B]» Trang Tiếp Theo ({}/{}) «[/B][/COLOR]'.format(
                min(end, total),
                total
            )
        )

        next_url = get_url(
            action='links',
            thread=thread_url,
            page=str(page + 1)
        )

        xbmcplugin.addDirectoryItem(_handle, next_url, next_li, True)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle, succeeded=True)


def call_fshare_folder_api(linkcode, page=1, per_page=FSHARE_FOLDER_PAGE_SIZE):
    api_url = (
        'https://www.fshare.vn/api/v3/files/folder'
        '?linkcode={}&sort=type,name&page={}&per-page={}'
    ).format(linkcode, page, per_page)

    r = requests.get(api_url, headers={'User-Agent': UA_FSHARE_API, 'Accept': 'application/json'}, timeout=20)
    r.raise_for_status()
    return r.json()


def get_fshare_folder_items(linkcode, page=1):
    try:
        data = call_fshare_folder_api(linkcode, page)
        items = data.get('items', [])
        has_next = len(items) >= FSHARE_FOLDER_PAGE_SIZE
        return items, has_next
    except Exception as e:
        log('Fshare folder error: {}'.format(e), xbmc.LOGERROR)
        return [], False


def list_fshare_folder(linkcode, page=1, title='', image=''):
    items, has_next = get_fshare_folder_items(linkcode, page)

    if not items:
        li = xbmcgui.ListItem(label='[COLOR red][B]Folder rỗng hoặc lỗi Fshare[/B][/COLOR]')
        xbmcplugin.addDirectoryItem(_handle, '', li, False)

    for item in items:
        item_type = item.get('type', 0)
        name = item.get('name', 'Unknown')
        item_code = item.get('linkcode', '')

        label = name

        if item_type == 1:
            label = '{} [COLOR yellow]| {}[/COLOR]'.format(name, format_size(item.get('size', 0)))

        li = xbmcgui.ListItem(label=label)
        set_video_info(li, label, title, image)

        if item_type == 1:
            li.setProperty('IsPlayable', 'true')
            url = get_url(action='play_fshare', linkcode=item_code)
            xbmcplugin.addDirectoryItem(_handle, url, li, False)
        else:
            url = get_url(
                action='fshare_folder',
                linkcode=item_code,
                page='1',
                title=title,
                image=image
            )
            xbmcplugin.addDirectoryItem(_handle, url, li, True)

    if has_next:
        li = xbmcgui.ListItem(label='[COLOR yellow][B]» Trang Tiếp Theo «[/B][/COLOR]')
        url = get_url(
            action='fshare_folder',
            linkcode=linkcode,
            page=str(page + 1),
            title=title,
            image=image
        )
        xbmcplugin.addDirectoryItem(_handle, url, li, True)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle, succeeded=True)


def ensure_fshare_settings_for_play():
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()

    if username and password:
        return True

    xbmcgui.Dialog().ok(ADDON_NAME, 'Bạn cần nhập tài khoản Fshare để phát phim.')
    addon.openSettings()

    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()

    return bool(username and password)


def fshare_login():
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()

    if not username or not password:
        raise Exception('Bạn chưa nhập tài khoản Fshare')

    response = requests.post(
        'https://api.fshare.vn/api/user/login',
        headers={
            'User-Agent': UA_FSHARE_API,
            'Accept': 'application/json'
        },
        json={
            'user_email': username,
            'password': password,
            'app_key': APP_KEY_FSHARE_API
        },
        timeout=20
    )

    data = response.json()

    if response.status_code != 200:
        raise Exception(data.get('msg', 'Login Fshare lỗi'))

    token = data.get('token', '')
    session_id = data.get('session_id', '')

    if not token or not session_id:
        raise Exception('Fshare không trả token/session')

    addon.setSetting('current_fshare_username', username)
    addon.setSetting('fshare_token', token)
    addon.setSetting('fshare_session_id', session_id)

    return token, session_id


def get_fshare_session():
    return (
        addon.getSetting('current_fshare_username').strip(),
        addon.getSetting('fshare_token').strip(),
        addon.getSetting('fshare_session_id').strip()
    )


def get_fshare_download_url(linkcode):
    if not ensure_fshare_settings_for_play():
        raise Exception('Thiếu tài khoản Fshare')

    username = addon.getSetting('username').strip()
    current_user, token, session_id = get_fshare_session()

    if not token or not session_id or username != current_user:
        token, session_id = fshare_login()

    file_url = 'https://www.fshare.vn/file/{}'.format(linkcode)

    def post_download(tok, sid):
        return requests.post(
            'https://api.fshare.vn/api/session/download',
            headers={
                'Accept': 'application/json',
                'User-Agent': UA_FSHARE_API,
                'Cookie': 'session_id={}'.format(sid),
                'Origin': 'https://www.fshare.vn',
                'Referer': 'https://www.fshare.vn/'
            },
            json={
                'url': file_url,
                'password': '',
                'token': tok,
                'zipflag': 0
            },
            timeout=20
        )

    response = post_download(token, session_id)

    if response.status_code == 201:
        token, session_id = fshare_login()
        response = post_download(token, session_id)

    data = response.json()

    download_url = data.get('location')

    if not download_url:
        raise Exception(data.get('msg', 'Không lấy được link play'))

    return download_url


def play_fshare(linkcode):
    try:
        stream_url = get_fshare_download_url(linkcode)
        play_item = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Lỗi phát video:\n{}'.format(e))
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())


def router(paramstring):
    params = dict(parse_qsl(paramstring))

    if not params:
        list_categories()
        return

    action = params.get('action', '')

    if action == 'threads':
        list_threads(
            params.get('category', ''),
            int(params.get('page', '1')),
            params.get('query', '')
        )
        return

    if action == 'links':
        list_links(
            params.get('thread', ''),
            int(params.get('page', '1'))
        )
        return

    if action == 'fshare_folder':
        list_fshare_folder(
            params.get('linkcode', ''),
            int(params.get('page', '1')),
            params.get('title', ''),
            params.get('image', '')
        )
        return

    if action == 'play_fshare':
        play_fshare(params.get('linkcode', ''))
        return

    xbmcplugin.endOfDirectory(_handle, succeeded=False)
    raise ValueError('Invalid paramstring: {}'.format(paramstring))


if __name__ == '__main__':
    router(sys.argv[2][1:])

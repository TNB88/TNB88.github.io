# -*- coding: utf-8 -*-
import xbmc
xbmc.log('[VUA PHIM] service loaded', xbmc.LOGINFO)

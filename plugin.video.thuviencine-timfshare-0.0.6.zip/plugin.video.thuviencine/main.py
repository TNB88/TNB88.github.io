# -*- coding: utf-8 -*-
import sys
import re
import requests
from urllib.parse import urlencode, parse_qsl, urlparse, urljoin, quote_plus
from bs4 import BeautifulSoup

import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin

_url = sys.argv[0]
_handle = int(sys.argv[1])

ADDON_NAME = 'TimFshare'
addon = xbmcaddon.Addon()

HOME_PAGE = (
    addon.getSetting('home_page').strip()
    or 'https://forum.timfshare.com'
).rstrip('/')

UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
HEADERS = {'User-Agent': UA}

UA_FSHARE_API = 'timfshare-kodi'
APP_KEY_FSHARE_API = 'dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt'
FSHARE_FOLDER_PAGE_SIZE = 50


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[TimFshare] {}'.format(msg), level)


def get_url(**kwargs):
    return '{}?{}'.format(_url, urlencode(kwargs))


def request_html(url):
    r = requests.get(url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    return r.text


def clean_text(text):
    return re.sub(r'\s+', ' ', text or '').strip()


def get_fshare_linkcode(url):
    path = urlparse(url).path
    parts = [p for p in path.split('/') if p]
    return parts[-1] if parts else ''


def format_size(bytes_size):
    try:
        size = float(bytes_size)
    except Exception:
        size = 0
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    i = 0
    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1
    return '{:.1f} {}'.format(size, units[i])


def list_categories():
    cats = [
        ('Phim ảnh', '/forums/phim-anh.3/'),
        ('Tìm kiếm', 'search'),
    ]
    for name, path in cats:
        li = xbmcgui.ListItem(label=name)
        li.getVideoInfoTag().setTitle(name)
        url = get_url(action='threads', category=path, page='1')
        xbmcplugin.addDirectoryItem(_handle, url, li, True)
    xbmcplugin.endOfDirectory(_handle)


def build_category_url(category, page=1, query=''):
    if category == 'search':
        if page <= 1:
            return HOME_PAGE + '/search/search?keywords={}&title_only=1'.format(quote_plus(query))
        return HOME_PAGE + '/search/search?keywords={}&title_only=1&page={}'.format(quote_plus(query), page)

    base = urljoin(HOME_PAGE + '/', category.lstrip('/'))
    if page <= 1:
        return base
    if base.endswith('/'):
        return base + 'page-{}'.format(page)
    return base + '/page-{}'.format(page)


def get_threads(category, page=1, query=''):
    if category == 'search' and not query:
        kb = xbmc.Keyboard('', 'Nhập tên phim cần tìm')
        kb.doModal()
        if not kb.isConfirmed():
            return [], ''
        query = kb.getText().strip()
        if not query:
            return [], ''

    try:
        html = request_html(build_category_url(category, page, query))
    except Exception as e:
        log('Get threads error: {}'.format(e), xbmc.LOGERROR)
        return [], query

    soup = BeautifulSoup(html, 'html.parser')
    threads = []
    added = set()
    nodes = soup.select('div.structItem--thread') or soup.select('div.structItem')

    for node in nodes:
        a = (
            node.select_one('a[data-tp-primary="on"]')
            or node.select_one('.structItem-title a')
            or node.select_one('a[href*="/threads/"]')
        )
        if not a:
            continue

        href = a.get('href', '')
        title = clean_text(a.get_text(' ', strip=True))
        if not href or not title or '/threads/' not in href:
            continue

        thread_url = urljoin(HOME_PAGE + '/', href)
        if thread_url in added:
            continue
        added.add(thread_url)

        thumb = ''
        img = node.select_one('img[src], img[data-src], img[data-url]')
        if img:
            thumb = img.get('data-url') or img.get('data-src') or img.get('src') or ''
            thumb = urljoin(HOME_PAGE + '/', thumb)

        plot = clean_text(node.get_text(' ', strip=True))[:700]
        threads.append({'name': title, 'url': thread_url, 'plot': plot, 'thumb': thumb})

    return threads, query


def list_threads(category, page=1, query=''):
    threads, query = get_threads(category, page, query)
    if not threads:
        li = xbmcgui.ListItem(label='[COLOR red][B]Không tìm thấy phim[/B][/COLOR]')
        xbmcplugin.addDirectoryItem(_handle, '', li, False)
        xbmcplugin.endOfDirectory(_handle)
        return

    for t in threads:
        li = xbmcgui.ListItem(label=t['name'])
        tag = li.getVideoInfoTag()
        tag.setTitle(t['name'])
        tag.setPlot(t.get('plot', ''))
        tag.setMediaType('movie')
        thumb = t.get('thumb', '')
        if thumb:
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': thumb})
        url = get_url(action='links', thread=t['url'])
        xbmcplugin.addDirectoryItem(_handle, url, li, True)

    next_li = xbmcgui.ListItem(label='[COLOR yellow][B]» Trang Tiếp Theo «[/B][/COLOR]')
    next_url = get_url(action='threads', category=category, page=str(page + 1), query=query)
    xbmcplugin.addDirectoryItem(_handle, next_url, next_li, True)
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)


def make_plot_from_content(content):
    if not content:
        return ''
    clone_text = content.get_text('\n', strip=True)
    lines = []
    for line in clone_text.split('\n'):
        line = clean_text(line)
        if not line:
            continue
        if 'fshare.vn/' in line.lower():
            continue
        if line.lower() in ('like', 'reply', 'quote'):
            continue
        lines.append(line)
    plot = '\n'.join(lines)
    return plot[:8000]


def parse_thread_detail(thread_url):
    try:
        html = request_html(thread_url)
    except Exception as e:
        log('Thread detail error: {}'.format(e), xbmc.LOGERROR)
        return {'title': '', 'plot': '', 'image': '', 'links': []}

    soup = BeautifulSoup(html, 'html.parser')
    title_el = soup.select_one('h1.p-title-value') or soup.select_one('h1')
    title = clean_text(title_el.get_text(' ', strip=True)) if title_el else ''

    content = soup.select_one('.bbWrapper') or soup.select_one('article.message-body') or soup.select_one('.message-content')
    image = ''
    plot = ''

    if content:
        for bad in content.select('script, style, noscript'):
            bad.decompose()
        plot = make_plot_from_content(content)
        img = content.select_one('img.bbImage[src], img[src], img[data-src], img[data-url]')
        if img:
            image = img.get('data-url') or img.get('data-src') or img.get('src') or ''
            image = urljoin(HOME_PAGE + '/', image)

    links = []
    added = set()
    for a in soup.select('a[href]'):
        href = a.get('href', '').strip()
        if 'fshare.vn/file/' not in href and 'fshare.vn/folder/' not in href:
            continue
        href = href.split('?')[0].strip()
        if href in added:
            continue
        added.add(href)
        code = get_fshare_linkcode(href)
        name = clean_text(a.get_text(' ', strip=True))
        if not name or 'fshare.vn' in name.lower():
            name = 'Fshare Folder - {}'.format(code) if '/folder/' in href else 'Fshare File - {}'.format(code)
        links.append({'name': name, 'url': href, 'linkcode': code, 'is_folder': '/folder/' in href})

    raw_links = re.findall(r'https?://(?:www\.)?fshare\.vn/(?:file|folder)/[A-Za-z0-9]+', html)
    for href in raw_links:
        href = href.split('?')[0].strip()
        if href in added:
            continue
        added.add(href)
        code = get_fshare_linkcode(href)
        links.append({'name': 'Fshare - {}'.format(code), 'url': href, 'linkcode': code, 'is_folder': '/folder/' in href})

    return {'title': title, 'plot': plot, 'image': image, 'links': links}


def list_links(thread_url):
    detail = parse_thread_detail(thread_url)
    links = detail.get('links', [])
    plot = detail.get('plot', '')
    image = detail.get('image', '')
    title = detail.get('title', '')

    if not links:
        li = xbmcgui.ListItem(label='[COLOR red][B]Không thấy link Fshare trong bài[/B][/COLOR]')
        if image:
            li.setArt({'thumb': image, 'icon': image, 'poster': image, 'fanart': image})
        tag = li.getVideoInfoTag()
        tag.setTitle(title or 'Không thấy link Fshare')
        tag.setPlot(plot)
        xbmcplugin.addDirectoryItem(_handle, '', li, False)
        xbmcplugin.endOfDirectory(_handle)
        return

    for v in links:
        li = xbmcgui.ListItem(label=v['name'])
        if image:
            li.setArt({'thumb': image, 'icon': image, 'poster': image, 'fanart': image})
        tag = li.getVideoInfoTag()
        tag.setTitle(title or v['name'])
        tag.setPlot(plot)
        tag.setMediaType('movie')

        if v['is_folder']:
            url = get_url(action='fshare_folder', linkcode=v['linkcode'])
            xbmcplugin.addDirectoryItem(_handle, url, li, True)
        else:
            li.setProperty('IsPlayable', 'true')
            url = get_url(action='play_fshare', linkcode=v['linkcode'])
            xbmcplugin.addDirectoryItem(_handle, url, li, False)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)


def call_fshare_folder_api(linkcode, page=1, per_page=FSHARE_FOLDER_PAGE_SIZE):
    api_url = 'https://www.fshare.vn/api/v3/files/folder?linkcode={}&sort=type,name&page={}&per-page={}'.format(linkcode, page, per_page)
    r = requests.get(api_url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    return r.json()


def get_fshare_folder_items(linkcode, page=1):
    try:
        data = call_fshare_folder_api(linkcode, page)
        items = data.get('items', [])
        has_next = len(items) >= FSHARE_FOLDER_PAGE_SIZE
        return items, has_next
    except Exception as e:
        log('Fshare folder error: {}'.format(e), xbmc.LOGERROR)
        return [], False


def list_fshare_folder(linkcode, page=1):
    items, has_next = get_fshare_folder_items(linkcode, page)
    if not items:
        li = xbmcgui.ListItem(label='[COLOR red][B]Folder rỗng hoặc lỗi Fshare[/B][/COLOR]')
        xbmcplugin.addDirectoryItem(_handle, '', li, False)

    for item in items:
        item_type = item.get('type', 0)
        name = item.get('name', 'Unknown')
        item_code = item.get('linkcode', '')
        label = name
        if item_type == 1:
            label = '{} [COLOR yellow]| {}[/COLOR]'.format(name, format_size(item.get('size', 0)))
        li = xbmcgui.ListItem(label=label)
        tag = li.getVideoInfoTag()
        tag.setTitle(label)
        tag.setMediaType('movie')
        if item_type == 1:
            li.setProperty('IsPlayable', 'true')
            url = get_url(action='play_fshare', linkcode=item_code)
            xbmcplugin.addDirectoryItem(_handle, url, li, False)
        else:
            url = get_url(action='fshare_folder', linkcode=item_code, page='1')
            xbmcplugin.addDirectoryItem(_handle, url, li, True)

    if has_next:
        li = xbmcgui.ListItem(label='[COLOR yellow][B]» Trang Tiếp Theo «[/B][/COLOR]')
        url = get_url(action='fshare_folder', linkcode=linkcode, page=str(page + 1))
        xbmcplugin.addDirectoryItem(_handle, url, li, True)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)


def fshare_login():
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()
    if not username or not password:
        raise Exception('Bạn chưa nhập tài khoản Fshare')

    r = requests.post(
        'https://api.fshare.vn/api/user/login',
        headers={'User-Agent': UA_FSHARE_API},
        json={'user_email': username, 'password': password, 'app_key': APP_KEY_FSHARE_API},
        timeout=20
    )
    data = r.json()
    if r.status_code != 200:
        raise Exception(data.get('msg', 'Login Fshare lỗi'))
    token = data.get('token', '')
    session_id = data.get('session_id', '')
    if not token or not session_id:
        raise Exception('Fshare không trả token/session')
    addon.setSetting('current_fshare_username', username)
    addon.setSetting('fshare_token', token)
    addon.setSetting('fshare_session_id', session_id)
    return token, session_id


def get_fshare_session():
    return (
        addon.getSetting('current_fshare_username').strip(),
        addon.getSetting('fshare_token').strip(),
        addon.getSetting('fshare_session_id').strip()
    )


def get_fshare_download_url(linkcode):
    username = addon.getSetting('username').strip()
    current_user, token, session_id = get_fshare_session()
    if not token or not session_id or username != current_user:
        token, session_id = fshare_login()

    file_url = 'https://www.fshare.vn/file/{}'.format(linkcode)
    r = requests.post(
        'https://api.fshare.vn/api/session/download',
        headers={'Accept': 'application/json', 'User-Agent': UA_FSHARE_API, 'Cookie': 'session_id={}'.format(session_id)},
        json={'url': file_url, 'password': '', 'token': token, 'zipflag': 0},
        timeout=20
    )
    if r.status_code == 201:
        token, session_id = fshare_login()
        r = requests.post(
            'https://api.fshare.vn/api/session/download',
            headers={'Accept': 'application/json', 'User-Agent': UA_FSHARE_API, 'Cookie': 'session_id={}'.format(session_id)},
            json={'url': file_url, 'password': '', 'token': token, 'zipflag': 0},
            timeout=20
        )
    data = r.json()
    direct = data.get('location', '')
    if not direct:
        raise Exception(data.get('msg', 'Không lấy được link play'))
    return direct


def play_fshare(linkcode):
    try:
        stream_url = get_fshare_download_url(linkcode)
        li = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(_handle, True, li)
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Lỗi phát video:\n{}'.format(e))
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())


def ensure_fshare_settings():
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()
    if username and password:
        return True
    addon.openSettings()
    username = addon.getSetting('username').strip()
    password = addon.getSetting('password').strip()
    return bool(username and password)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        if not ensure_fshare_settings():
            xbmcgui.Dialog().ok(ADDON_NAME, 'Bạn phải nhập tài khoản Fshare')
            return
        list_categories()
        return

    action = params.get('action', '')
    if action == 'threads':
        list_threads(params.get('category', ''), int(params.get('page', '1')), params.get('query', ''))
        return
    if action == 'links':
        list_links(params.get('thread', ''))
        return
    if action == 'fshare_folder':
        list_fshare_folder(params.get('linkcode', ''), int(params.get('page', '1')))
        return
    if action == 'play_fshare':
        play_fshare(params.get('linkcode', ''))
        return
    raise ValueError('Invalid paramstring: {}'.format(paramstring))


if __name__ == '__main__':
    router(sys.argv[2][1:])

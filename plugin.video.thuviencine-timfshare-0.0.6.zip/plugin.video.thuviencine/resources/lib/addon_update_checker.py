# -*- coding: utf-8 -*-

import requests
import xbmc
import xbmcgui
import xbmcaddon
from datetime import datetime

addon = xbmcaddon.Addon()

APP_ID = 'plugin.video.thuviencine'

CONFIG_URL = (
    'https://thuviencine.github.io/'
    'plugin.video.thuviencine/config.json'
)

UA = (
    'Mozilla/5.0 (X11; Linux x86_64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/59.0.3071.109 Safari/537.36'
)

def parse_version(version):
    return tuple(
        int(part)
        for part in version.split('.')
        if part.isdigit()
    )

def check_update():
    try:
        response = requests.get(
            CONFIG_URL,
            headers={
                'User-Agent': UA
            },
            timeout=10
        )

        response.raise_for_status()

        data = response.json()

        latest_version = data.get(
            'version',
            ''
        ).strip()

        message = data.get(
            'message_vi',
            'Đã có phiên bản mới'
        )

        if not latest_version:
            return

        current_version = addon.getAddonInfo(
            'version'
        )

        # xbmc.log(
        #     '[%s] Current: %s - Latest: %s'
        #     % (
        #         APP_ID,
        #         current_version,
        #         latest_version
        #     ),
        #     xbmc.LOGINFO
        # )

        if (
            parse_version(latest_version)
            <= parse_version(current_version)
        ):
            return

        today = datetime.now().strftime(
            '%Y-%m-%d'
        )

        last_notify_date = addon.getSetting(
            'last_notify_date'
        )

        if last_notify_date == today:
            return

        xbmcgui.Dialog().ok(
            (
                '[B][COLOR deepskyblue]ThuVienCine[/COLOR][/B] '
                '[COLOR silver]%s[/COLOR] '
                '→ '
                '[COLOR springgreen]%s[/COLOR] '
                '[COLOR gold]• Có phiên bản mới[/COLOR]'
            ) % (
                current_version,
                latest_version
            ),
            message
        )

        addon.setSetting(
            'last_notify_date',
            today
        )

    except Exception as e:
        xbmc.log(
            '[%s] Check update failed: %s'
            % (
                APP_ID,
                str(e)
            ),
            xbmc.LOGERROR
        )